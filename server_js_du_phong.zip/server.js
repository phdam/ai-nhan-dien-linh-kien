import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const ROOT = path.dirname(new URL(import.meta.url).pathname);

const SYSTEM_PROMPT = `Bạn là trợ lý kỹ thuật nhận diện linh kiện điện, điện tử, thiết bị công nghiệp và bảng điều khiển.
Quy tắc bắt buộc:
1) Quan sát ảnh thật cẩn thận; mô tả những gì nhìn thấy trước khi kết luận.
2) Đọc mã, logo, chữ in theo đúng những gì nhìn thấy. Dùng [không rõ] cho phần không đọc được; không tự bịa.
3) Nêu nhận diện có khả năng nhất, mức độ chắc chắn (cao/vừa/thấp) và các khả năng thay thế nếu phù hợp.
4) Phân biệt rõ dữ kiện quan sát được, suy luận và thông tin đã xác minh trên nguồn.
5) Khi cần mã linh kiện/datasheet/thông số hiện hành, hãy dùng web search; ưu tiên trang nhà sản xuất, datasheet PDF, nhà phân phối uy tín. Gắn URL nguồn cụ thể và nói nguồn xác nhận điều gì.
6) Nếu ảnh mờ/thiếu góc, yêu cầu ảnh cận cảnh, nhãn bên hông, đầu nối hoặc số model; không khẳng định quá mức.
7) Không hướng dẫn đấu điện nguy hiểm khi chưa xác định rõ thiết bị. Nhắc ngắt nguồn trước khi tháo/chụp bên trong thiết bị.
8) Trả lời bằng tiếng Việt, dễ hiểu, theo cấu trúc:
- Nhận diện sơ bộ
- Chữ/mã đọc được
- Dấu hiệu nhận biết
- Công dụng và thông số đã xác minh
- Datasheet / trang hãng / nguồn tham khảo (liên kết)
- Độ chắc chắn và bước kiểm tra tiếp theo
Nếu hình chỉ là toàn bộ thiết bị/bảng điều khiển chứ không phải linh kiện rời, hãy nhận diện thiết bị ở mức có thể và yêu cầu ảnh nhãn model rõ hơn.`;

const mimeByExt = { ".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".css":"text/css; charset=utf-8", ".md":"text/markdown; charset=utf-8" };
function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type, "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type", "Access-Control-Allow-Methods":"GET,POST,OPTIONS"});
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}
function extractText(data) {
  return (data?.candidates || []).flatMap(c => c?.content?.parts || []).map(p => p.text || "").filter(Boolean).join("\n") || "AI chưa trả về nội dung. Hãy thử lại với ảnh rõ hơn.";
}
const server = http.createServer(async (req,res) => {
  if (req.method === "OPTIONS") return send(res,204,"");
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (url.pathname === "/api/health") return send(res,200,{ok:true,configured:!!API_KEY,model:MODEL});
  if (url.pathname === "/api/analyze" && req.method === "POST") {
    if (!API_KEY) return send(res,503,{error:"Máy chủ chưa được cấu hình GEMINI_API_KEY. Hãy thiết lập khóa API trong môi trường máy chủ; không dán khóa vào giao diện HTML."});
    let raw = "";
    req.on("data", chunk => { raw += chunk; if(raw.length > 30_000_000) req.destroy(); });
    req.on("end", async () => {
      try {
        const body = JSON.parse(raw || "{}");
        const question = String(body.question || "Hãy nhận diện thiết bị/linh kiện trong ảnh.").slice(0,5000);
        const images = Array.isArray(body.images) ? body.images.slice(0,10) : [];
        if (!images.length) return send(res,400,{error:"Cần ít nhất một ảnh."});
        const parts = [{text:`${SYSTEM_PROMPT}\n\nYêu cầu người dùng: ${question}\nHãy phân tích tất cả ảnh đính kèm. Nếu là các khung hình của cùng một video, tổng hợp các dấu hiệu nhất quán.`}];
        for (const image of images) {
          if (typeof image.data !== "string" || !/^data:image\/(jpeg|jpg|png|webp|gif);base64,/i.test(image.data)) continue;
          if (image.data.length > 12_000_000) continue;
          const match = image.data.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
          if (match) parts.push({inline_data:{mime_type:match[1],data:match[2]}});
        }
        if (parts.length < 2) return send(res,400,{error:"Không có ảnh hợp lệ hoặc ảnh quá lớn. Hãy thử ảnh JPG/PNG/WebP nhỏ hơn."});
        const payload = {contents:[{role:"user",parts}], tools:[{google_search:{}}], generationConfig:{temperature:0.2,maxOutputTokens:1800}};
        const apiRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(API_KEY)}`, {
          method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)
        });
        const data = await apiRes.json();
        if (!apiRes.ok) return send(res,apiRes.status,{error:data?.error?.message || "Gemini API trả về lỗi.", details:data?.error?.status || ""});
        return send(res,200,{answer:extractText(data),model:MODEL});
      } catch (e) {
        return send(res,500,{error:"Không xử lý được yêu cầu: "+String(e.message || e)});
      }
    });
    return;
  }
  let pathname = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
  const file = path.resolve(ROOT, "." + pathname);
  if (!file.startsWith(path.resolve(ROOT))) return send(res,403,"Forbidden","text/plain");
  fs.readFile(file,(err,buf)=>{ if(err) return send(res,404,"Không tìm thấy tệp.","text/plain; charset=utf-8"); send(res,200,buf,mimeByExt[path.extname(file)] || "application/octet-stream"); });
});
server.listen(PORT,()=>console.log(`AI Linh Kiện chạy tại http://localhost:${PORT}`));
